// pages/order/shopCar/shopCar.js
const api = require('../../../config');
const template = require('../../../common/templates/byTemplates');
const byUser = require('../../../utils/user');
const util = require('../../../utils/util');
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    totalPrice: 0,
    selectedAllStatus: true,
    // suppliersData: [],
    customData: [],//定制信息数据
    startX:0,
    startY:0,
    startLeft:0,
    isAndroid: util.isAndroid(),
    isFirstShow: true,
    preSupplierIndex: 0,
    preGoodsIndex:0,
    hasSelected:true,
    defaultImageSrc:"/common/img/img-default-128_128.png",
    daleteBtnWidth:0,
    pageOnShow:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.loginIn();
    let animation = wx.createAnimation({
      duration:200,
      timingFunction:'ease'
    });
    this.animation = animation;
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    let _this = this;
    this.setData({
      "templateData.showOffline": false,
    })
    if (_this.data.pageOnShow) {
      let needLogin = byUser.needLogin();
      if (needLogin) {
        byUser.loginByWeixin({
          success: function () {
            _this.getSuppliersData();
          },
          fail: function () {
            template.showOffline({
              context: _this,
              title: "网络异常，请稍后重试",
              callBack: _this.loginIn,
            })
          }
        });
      } else {
        _this.getSuppliersData();
      }
    }
    _this.setData({
      pageOnShow: true
    });
    util.trackRequest();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    let _this = this;
    _this.setData({
      pageOnShow:false
    });
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },
  stopMove: function () {
    //捕获touchmove事件来阻止底层滚动
  },

  // 判断是否登录
  loginIn:function(){
    let _this = this;
    let needLogin = byUser.needLogin();
    if (needLogin) {
      byUser.loginByWeixin({
        success: function () {
          _this.getSuppliersData();
        },
        fail: function () {
          template.showOffline({
            context: _this,
            title: "网络异常，请稍后重试",
            callBack: _this.loginIn,
          })
        }
      });
    } else {
      _this.getSuppliersData();
    }
  },

  /**
   * 请求初始化数据
   */
  getSuppliersData:function(){
    let _this = this;
    // wx.showNavigationBarLoading();
    if (_this.data.isFirstShow){
      wx.showLoading({ title: '加载中...' });
    }else{
      wx.showNavigationBarLoading();
    }
    
    util.byRequest({
      url: api.getShopCarInfoUrl,
      data: {},
      method: 'POST',
      dataType: 'json',
      success: function (res) {
        wx.hideNavigationBarLoading();
        wx.hideLoading();
        if (res.data.success == 1) {
          let suppliersData = res.data.data.suppliers;
          suppliersData.forEach(function (supplier) {
            supplier.selected = true;
            supplier.products.forEach(function (product) {
              if (product.shopCar.saleStatus == 1) {
                product.selected = true;
                // supplier.selected = true;
              }
            });
          });
        
          _this.setData({
            isFirstShow: false,
            suppliersData: suppliersData,
            // totalPrice: res.data.data.totalPrice,
            customStatus: false,
            preSupplierIndex: 0,
            preGoodsIndex: 0
          });

          suppliersData.forEach(function (supplier, supplierIndex) {
            supplier.products.forEach(function (product, goodsIndex) {
              let obj = {};
              let key = "suppliersData[" + supplierIndex + "].products[" + goodsIndex + "].animationData";
              obj[key] = _this.animation.left(0).step().export();
              _this.setData(obj);
            });
          });
          _this.checkGoodsSelect();
          _this.calTotalPrice();
        } else {
          //请求初始化数据失败
          if (res.data.error.code == 200000){
            wx.showModal({
              title: '操作失败',
              content: '网络请求异常，点击重试',
              confirmText:'重试',
              confirmColor: "#7f4395",
              success: function (res) {
                if (res.confirm) {
                  byUser.clearLoginStatus();
                  byUser.loginByWeixin({
                    success: _this.getSuppliersData,
                    fail:function(){
                      template.showOffline({
                        context: _this,
                        title: "网络异常，请稍后重试",
                        callBack: _this.loginIn,
                      })
                    }
                  });
                } else if (res.cancel) {
                  // 点击了取消
                  template.showOffline({
                    context: _this,
                    title: "网络异常，请稍后重试",
                    callBack: _this.loginIn,
                  })
                }
              }
            })
          }else{
            template.showOffline({
              context: _this,
              title: "网络异常，请稍后重试",
              callBack: _this.getSuppliersData,
            })
          }
        }
      },
      fail: function (res) {
        wx.hideNavigationBarLoading();
        wx.hideLoading();
        // 错误提示
        template.showOffline({
          context: _this,
          title: "网络异常，请稍后重试",
          callBack: _this.getSuppliersData,
        })
      },
    })
  },  
  touchS: function (ev) {
    let _this= this;
    let daleteBtnWidth;
    let suppliersData = _this.data.suppliersData;
    let supplierIndex = _this.data.preSupplierIndex;
    let goodsIndex = _this.data.preGoodsIndex;
    let styleTxt = '0';
    wx.createSelectorQuery().select('.goods-delete').boundingClientRect(function (rect) {
      _this.setData({
        daleteBtnWidth:rect.width
      });
      daleteBtnWidth = rect.width;
    }).exec();
    if (!(supplierIndex == ev.currentTarget.dataset.supplierIndex && goodsIndex == ev.currentTarget.dataset.goodsIndex)){
      suppliersData[supplierIndex].products[goodsIndex].animationData = _this.animation.left(styleTxt).step().export();
      _this.setData({
        suppliersData: suppliersData,
        preSupplierIndex: ev.currentTarget.dataset.supplierIndex,
        preGoodsIndex: ev.currentTarget.dataset.goodsIndex
      });
    }
    if(ev.touches.length == 1){
      _this.setData({
        startX: ev.touches[0].clientX,
        startY: ev.touches[0].clientY,
        startLeft: ev.currentTarget.offsetLeft,
      });
    }
  },
  touchM: function (ev) {
    let _this = this;
    let daleteBtnWidth = _this.data.daleteBtnWidth;
    let suppliersData = _this.data.suppliersData;
    let supplierIndex = ev.currentTarget.dataset.supplierIndex;
    let goodsIndex = ev.currentTarget.dataset.goodsIndex;
    let startLeft = _this.data.startLeft;
    let styleTxt = '';
    if(ev.touches.length == 1){
      let disX = ev.touches[0].clientX - _this.data.startX;
      if(disX <0){
        styleTxt = Math.abs(disX) > daleteBtnWidth ? "-"+daleteBtnWidth : disX ;
      }else if(disX > 0){
        styleTxt = Math.abs(disX) > daleteBtnWidth ? daleteBtnWidth : disX ;
      }else{
        return;
      }
      let obj = {};
      let key = "suppliersData[" + supplierIndex + "].products[" + goodsIndex + "].animationData";
      obj[key] = _this.animation.left(Number(styleTxt) + Number(startLeft)).step().export();
      _this.setData(obj);
    }
  },
  touchE: function (ev) {
    let _this = this;
    let daleteBtnWidth = _this.data.daleteBtnWidth;
    let suppliersData = _this.data.suppliersData;
    let supplierIndex = ev.currentTarget.dataset.supplierIndex;
    let goodsIndex = ev.currentTarget.dataset.goodsIndex;
    let styleTxt = '';
    let startLeft = _this.data.startLeft;
    if (ev.changedTouches.length == 1){
      let endX = ev.changedTouches[0].clientX;
      let disX = endX - _this.data.startX;
      if(disX < 0){
        styleTxt = Math.abs(disX) > daleteBtnWidth ? '-' + daleteBtnWidth + 'px' : startLeft;
      }else if(disX > 0){
        styleTxt = Math.abs(disX) > daleteBtnWidth ? '0' : startLeft;
      }else{
        return;
      }
      let obj={};
      let key = "suppliersData[" + supplierIndex + "].products[" + goodsIndex +"].animationData";
      obj[key] = _this.animation.left(styleTxt).step().export();
      _this.setData(obj);
    }
  },
  //商家全选事件
  selectSupplier:function(ev){
    let _this = this;
    let suppliersData = _this.data.suppliersData;
    let supplierIndex = ev.currentTarget.dataset.supplierIndex;
    if (suppliersData[supplierIndex].selected){
      suppliersData[supplierIndex].selected = false;
      suppliersData[supplierIndex].products.forEach(function(product){
        if (product.shopCar.saleStatus == 1){
          product.selected = false;
        }
      });
    }else{
      suppliersData[supplierIndex].selected = true;
      suppliersData[supplierIndex].products.forEach(function (product) {
        if (product.shopCar.saleStatus == 1) {
          product.selected = true;
          // suppliersData[supplierIndex].selected = true;
        }
      });
    }
    _this.setData({
      suppliersData: suppliersData,
    });
    _this.calTotalPrice();
    _this.checkGoodsSelect();
  },
  //商品选中事件
  selectGoods:function(ev){
    let _this = this;
    let suppliersData = _this.data.suppliersData;
    let supplierIndex = ev.currentTarget.dataset.supplierIndex;
    let goodsIndex = ev.currentTarget.dataset.goodsIndex;
    if (suppliersData[supplierIndex].products[goodsIndex].selected){
      suppliersData[supplierIndex].products[goodsIndex].selected = false;
    }else{
      suppliersData[supplierIndex].products[goodsIndex].selected = true;
    }
    if (_this.checkSullpierSelect(supplierIndex)){
      suppliersData[supplierIndex].selected = true;
    }else{
      suppliersData[supplierIndex].selected = false;
    }
    _this.setData({
      suppliersData: suppliersData,
    });
    _this.calTotalPrice();
    _this.checkGoodsSelect();
  },
  // 全选
  selectAll:function(){
    let _this = this;
    let suppliersData = _this.data.suppliersData;
    let selectedAllStatus = _this.data.selectedAllStatus;
    if (selectedAllStatus){
      selectedAllStatus = false;
      suppliersData.forEach(function(supplier){
        supplier.selected = false;
        supplier.products.forEach(function(product){
          if (product.shopCar.saleStatus == 1) {
            product.selected = false;
          }
        });
      });
    }else{
      selectedAllStatus = true;
      suppliersData.forEach(function (supplier) {
        supplier.selected = true;
        supplier.products.forEach(function (product) {
          if (product.shopCar.saleStatus == 1) {
            product.selected = true;
          }
        });
      });
    }

    _this.setData({
      suppliersData: suppliersData,
      selectedAllStatus: selectedAllStatus
    });
    _this.calTotalPrice();
  },
  // 检查商家下的商品是否已经全选
  checkSullpierSelect:function(supplierIndex){
    let _this = this;
    let suppliersData = _this.data.suppliersData;
    let result = suppliersData[supplierIndex].products.every(function (product){
      if (product.shopCar.saleStatus == 0){
        return true;
      }
      if (product.selected){
        return true;
      }else{
        return false;
      }
    });

    return result;
  },
  // 检查全部商品是已经全选
  checkGoodsSelect: function (){
    let _this = this;
    let suppliersData = _this.data.suppliersData;
    let selectedAllStatus = _this.data.selectedAllStatus;
    let result = suppliersData.every(function(supplier){
      return supplier.selected;
    });
    if(result){
      selectedAllStatus = true;
    }else{
      selectedAllStatus = false;
    }
    _this.setData({
      selectedAllStatus: selectedAllStatus
    });
  },
  // 计算总价格
  calTotalPrice:function(){
    let _this = this;
    let totalPrice = 0;
    let suppliersData = _this.data.suppliersData;
    let hasSelected = false;
    suppliersData.forEach(function(supplier){
      supplier.products.forEach(function (product) {
        if (product.selected){
          totalPrice += product.shopCar.num * product.price;
          hasSelected = true;
        }
      });
    });

    _this.setData({
      totalPrice: totalPrice,
      hasSelected: hasSelected
    });
  },
  // 删除购物车
  deleteGoods:function(ev){
    let _this = this;
    let needLogin = byUser.needLogin();
    if (needLogin) {
      byUser.loginByWeixin({
        success:function(){
          _this.deleteGoodsRequest(ev);
        },
        fail:function(){
          template.showToast({ context: _this, title: '网络异常，请稍后再试' });
        }
      });
    } else {
      _this.deleteGoodsRequest(ev);
    }
  },
  deleteGoodsRequest:function(ev){
    let _this =this;
    let suppliersData = _this.data.suppliersData;
    let supplierIndex = ev.currentTarget.dataset.supplierIndex;
    let goodsIndex = ev.currentTarget.dataset.goodsIndex;
    let shopCarId = suppliersData[supplierIndex].products[goodsIndex].shopCar.shopCarId;
    wx.showNavigationBarLoading();
    util.byRequest({
      url: api.deleteGoodsUrl,
      data: {
        shopCarIds: shopCarId.toString()
      },
      method: 'POST',
      success: function (res) {
        wx.hideNavigationBarLoading();
        if (res.data.success == 1) {
          suppliersData[supplierIndex].products.splice(goodsIndex, 1);
          if (suppliersData[supplierIndex].products.length == 0) {
            suppliersData.splice(supplierIndex, 1);
          } else {
            let result = suppliersData[supplierIndex].products.every(function (product) {
              if (product.shopCar.saleStatus == 0) {
                return true;
              }
              if (product.selected) {
                return true;
              } else {
                return false;
              }
            });
            if (result) {
              suppliersData[supplierIndex].selected = true;
            } else {
              suppliersData[supplierIndex].selected = false;
            }
          }
          
          _this.setData({
            suppliersData: suppliersData,
            preSupplierIndex: 0,
            preGoodsIndex: 0
          });
          suppliersData.forEach(function (supplier, supplierIndex) {
            supplier.products.forEach(function (product, goodsIndex) {
              let obj = {};
              let key = "suppliersData[" + supplierIndex + "].products[" + goodsIndex + "].animationData";
              obj[key] = _this.animation.left(0).step().export();
              _this.setData(obj);
            });
          });
          _this.calTotalPrice();
          _this.checkGoodsSelect();
        } else {
          // 错误提示
          if(res.data.error.code == 200000){
            wx.showModal({
              title: '操作失败',
              content: '网络请求异常，点击重试',
              confirmText: '重试',
              confirmColor: "#7f4395",
              success: function (res) {
                if (res.confirm) {
                  byUser.clearLoginStatus();
                  byUser.loginByWeixin({
                    success: function(){
                      _this.deleteGoodsRequest(ev);
                    },
                    fail: function () {
                      template.showToast({
                        context: _this,
                        title: "网络异常，请稍后再试",
                        duration: 2000
                      })
                    }
                  });
                } else if (res.cancel) {
                  // todo点击了取消
                }
              }
            })
          }else{
            template.showToast({
              context: _this,
              title: res.data.error.message,
              duration: 2000
            })
          }
        }
      },
      fail: function (res) {
        // 错误提示
        template.showToast({
          context: _this,
          title: "网络异常，请稍后再试",
          duration: 2000
        })
      }
    });
  },
  //变更商品数量
  modifyNum: function (ev) {
    let _this = this;
    let needLogin = byUser.needLogin();
    if (needLogin) {
      byUser.loginByWeixin({
        success: function () {
          _this.modifyNumRequest(ev);
        },
        fail: function () {
          template.showToast({ context: _this, title: '网络异常，请稍后再试' });
        }
      });

    } else {
      _this.modifyNumRequest(ev);
    }
  },
  modifyNumRequest:function(ev){
    let _this = this;
    let suppliersData = _this.data.suppliersData;
    let supplierIndex = ev.currentTarget.dataset.supplierIndex;
    let goodsIndex = ev.currentTarget.dataset.goodsIndex;
    let num = suppliersData[supplierIndex].products[goodsIndex].shopCar.num;
    let shopCarId = suppliersData[supplierIndex].products[goodsIndex].shopCar.shopCarId;
    let status = ev.currentTarget.dataset.status;//1:允许点击   0:置灰，不允许点击
    let modifyType = ev.currentTarget.dataset.modifyType;//0：减一，1：加一
    if(status ==1){
      if (modifyType == 1){
        num = num + 1;
      }else{
        num = num - 1;
      }
      wx.showNavigationBarLoading();
      util.byRequest({
        url: api.modifyNumUrl,
        data: {
          num: num,
          shopCarId: shopCarId
        },
        method: 'POST',
        success: function (res) {
          wx.hideNavigationBarLoading();
          let obj = {};
          if (res.data.success == 1) {

            // suppliersData[supplierIndex].products[goodsIndex].shopCar.num = num ;
            // suppliersData[supplierIndex].products[goodsIndex].shopCar.store = res.data.data.store;
            obj["suppliersData[" + supplierIndex + "].products[" + goodsIndex + "].shopCar.num"] = num;
            obj["suppliersData[" + supplierIndex + "].products[" + goodsIndex + "].shopCar.store"] = res.data.data.store;
          } else {
            // 错误提示
            if(res.data.error.code == 200000){
              wx.showModal({
                title: '操作失败',
                content: '网络请求异常，点击重试',
                confirmText: '重试',
                confirmColor: "#7f4395",
                success: function (res) {
                  if (res.confirm) {
                    byUser.clearLoginStatus();
                    byUser.loginByWeixin({
                      success: function(){
                        _this.modifyNumRequest(ev);
                      },
                      fail: function () {
                        template.showToast({
                          context: _this,
                          title: "网络异常，请稍后再试",
                          duration: 2000
                        })
                      }
                    });
                  } else if (res.cancel) {
                    // todo点击了取消
                  }
                }
              })
            }else{
              obj["suppliersData[" + supplierIndex + "].products[" + goodsIndex + "].shopCar.num"] = suppliersData[supplierIndex].products[goodsIndex].shopCar.num;
              obj["suppliersData[" + supplierIndex + "].products[" + goodsIndex + "].shopCar.store"] = res.data.data.store;
              template.showToast({
                context: _this,
                title: res.data.error.message,
                duration: 2000
              })
            }
          }
          _this.setData(obj);
          _this.calTotalPrice();
        },
        fail:function(res){
          // 错误提示
          template.showToast({
            context: _this,
            title: "网络异常，请稍后再试",
            duration: 2000
          })
        }
      });
    }
  },
  //获取已经勾选的shopCarIds集合
  getShopCarIds:function(){
    let shopCarIds = [];
    let _this = this;
    let suppliersData = _this.data.suppliersData;
    suppliersData.forEach(function (supplier) {
      supplier.products.forEach(function (product) {
        if (product.selected) {
          shopCarIds.push(product.shopCar.shopCarId);
        }
      });
    });
    return shopCarIds;
  },
  //去结算
  prepareGotoOrder: function () {
    let _this = this;
    let needLogin = byUser.needLogin();
    if (needLogin) {
      byUser.clearLoginStatus();
      byUser.loginByWeixin({
        success: function () {
          _this.prepareGotoOrderRequest();
        },
        fail: function () {
          template.showToast({ context: _this, title: '网络异常，请稍后再试' });
        }
      });

    } else {
      _this.prepareGotoOrderRequest();
    }
  },
  prepareGotoOrderRequest:function(){
    let _this = this;
    let shopCarIds = _this.getShopCarIds();
    if (shopCarIds.length){
      wx.showLoading({
        title: '加载中...',
        mask:true
      });
      util.byRequest({
        url: api.prepareGotoOrderUrl,
        data: {
          shopCarIds: shopCarIds.join(',')
        },
        method: 'POST',
        dataType: 'json',
        success: function (res) {
          wx.hideLoading({
            mask: true
          });
          if (res.data.success == 1) {
            // 跳转至确认订单页
            wx.navigateTo({
              url: '/pages/order/confirmOrder/confirmOrder'
            });
          } else {
            // 错误提示
            if(res.data.error.code == 200000){
              wx.showModal({
                title: '操作失败',
                content: '网络请求异常，点击重试',
                confirmText: '重试',
                confirmColor: "#7f4395",
                success: function (res) {
                  if (res.confirm) {
                    byUser.clearLoginStatus();
                    byUser.loginByWeixin({
                      success: _this.prepareGotoOrderRequest,
                      fail: function () {
                        template.showToast({
                          context: _this,
                          title: "网络异常，请稍后再试",
                          duration: 2000
                        })
                      }
                    });
                  } else if (res.cancel) {
                    // todo点击了取消
                  }
                }
              })
            }else{
              template.showToast({
                context: _this,
                title: res.data.error.message,
                duration: 2000
              })
            }
          }
        },
        fail: function(res){
          // 错误提示
          template.showToast({
            context: _this,
            title: "网络异常，请稍后再试",
            duration: 2000
          })
        }
      });
    }
  },
  //查看定制信息
  showCustom:function(ev){
    let _this = this;
    let suppliersData = _this.data.suppliersData;
    let supplierIndex = ev.currentTarget.dataset.supplierIndex;
    let goodsIndex = ev.currentTarget.dataset.goodsIndex;
    _this.setData({
      customData: suppliersData[supplierIndex].products[goodsIndex].shopCar.customData,
      customStatus:true
    });
  },
  hideCustom:function(){
    this.setData({
      customStatus: false
    });
  },
  //图片加载失败显示默认图
  imageError: function (ev) {
    let _this = this;
    let supplierIndex = ev.currentTarget.dataset.supplierIndex;
    let goodsIndex = ev.currentTarget.dataset.goodsIndex;
    let defaultSrc = _this.data.defaultImageSrc;

    let imgObject = "suppliersData[" + supplierIndex + "].products[" + goodsIndex + "].img_url_50";
    let errorImg = {};
    errorImg[imgObject] = defaultSrc;
    _this.setData(errorImg);
  },
  //定制信息图片加载失败
  imageErrorDesign: function () {
    let _this = this;
    _this.data.customData.forEach(function (item) {
      if (item.type == 1) {
        item.value = "/common/img/default-750-750.png";
      }
    });
    _this.setData({
      customData: _this.data.customData
    });
  },
  // 非低模商品点击提示
  errorTap:function(){
    let _this = this;
    template.showToast({
      context: _this,
      title: "小程序暂不支持查看该类商品详情",
      duration: 2000
    })
  },
})